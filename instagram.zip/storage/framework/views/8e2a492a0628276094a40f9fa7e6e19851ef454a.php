<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<br><br>
<br>
<br>
<section class="zxx"> 
    <div class="zxc cs">
     <img src="<?php echo e(asset('img/be-giang-1.png')); ?>" class="zxz">
        <div  class="zxv"> 
            <i class="fa fa-2x fa-play zxb"></i>
            <div class="zxn">
                <i class="fa fa-heart"></i>
                <span> 12.6k </span>
                <i class="fa fa-comment"></i> 
                <span > 72 </span>
            </div> 
        </div>
    </div>
<div class="zxc cs">
    <img src="<?php echo e(asset('img/be-giang-1.png')); ?>" class="zxz">
    <div  class="zxv"> 
        <i class="fa fa-2x fa-play zxb"></i>
        <div class="zxn">
            <i class="fa fa-heart"></i>
            <span> 12.6k </span>
            <i class="fa fa-comment"></i> 
            <span > 72 </span>
        </div> 
    </div>
</div>
<div class="zxc cs">
     <img src="<?php echo e(asset('img/be-giang-1.png')); ?>" class="zxz">
        <div  class="zxv"> 
            <i class="fa fa-2x fa-play zxb"></i>
            <div class="zxn">
                <i class="fa fa-heart"></i>
                <span> 12.6k </span>
                <i class="fa fa-comment"></i> 
                <span > 72 </span>
            </div> 
        </div>
</div>
<div class="zxc cs">
    <img src="<?php echo e(asset('img/be-giang-1.png')); ?>" class="zxz">
        <div  class="zxv"> 
            <i class="fa fa-2x fa-play zxb"></i>
            <div class="zxn">
                <i class="fa fa-heart"></i>
                <span> 12.6k </span>
                <i class="fa fa-comment"></i> 
                <span > 72 </span>
            </div> 
        </div>
    </div>
</section>
<footer>
        <a href="">GIỚI THIỆU</a>
        <a href="">TRỢ GIÚP</a>
        <a href="">BÁO CHÍ</a>
        <a href="">API</a>
        <a href="">VIỆC LÀM</a>
        <a href="">QUYỀN RIÊNG TƯ</a>
        <a href="">ĐIỀU KHOẢN</a>
        <a href="">VỊ TRÍ</a>
        <a href="">TÀI KHOẢN LIÊN QUAN NHẤT</a>
        <a href="">HASHTAG</a>
        <a href="">NGÔN NGỮ</a>
        <p>&copy;  2020 INSTAGRAM FROM FACEBOOK</p>
</footer>
    <script src="https://use.fontawesome.com/452826394c.js"></script>
     
</body>
</html><?php /**PATH D:\xampp\htdocs\instagram\resources\views/explore.blade.php ENDPATH**/ ?>