
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
 
<!-- <div id="id01" class="w3-modal d-none"> -->
<div id="id01" class="w3-modal d-none">
    <div class="w3-modal-content animate__flipInX d-flex po"> 
      <div class="clr pp">
         <span class="cs closemodal">&times;</span>
         <p><?php echo e(__('translate.New Message')); ?></p>
         <button class="disabled nexts"><?php echo e(__('translate.Next')); ?></button>
      </div>

      <div class="pi"> 
         <form >
         <?php echo csrf_field(); ?>
         <p class="pr"><?php echo e(__('translate.To')); ?>:</p>
        <div class="pe">
        <div class="d-flex pw">
             
         </div>
        </div>
         <input type="text" name="key" placeholder="<?php echo e(__('translate.Search')); ?>..." id="search" autocomplete="off">
         </form>
      </div>

      <div class="pu "> 
         <b class="pq"><?php echo e(__('translate.Suggested')); ?></b>
         <?php $__currentLoopData = $chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="clr py cs py<?php echo e($list->id); ?>"> 
            <img src="<?php echo e(pare_url_file($list->friends->avatar,'user')); ?>" class="rounded-circle">
            <div> 
               <b><?php echo e($list->friends->user); ?></b><br>
               <p class="os"><?php echo e($list->friends->c_name); ?></p> 
            </div>
            <button class="cs hihi<?php echo e($key); ?>"><i class="fa fa-lg fa-check haha<?php echo e($key); ?>"></i></button>
         </div>

         <script> 
        

            $('.py<?php echo e($list->id); ?>').on('click',function(){
               if($('.hihi<?php echo e($key); ?>').hasClass('background-blue')){
                  $('.hihi<?php echo e($key); ?>').removeClass('background-blue'); 
                  $('.pt<?php echo e($key); ?>').remove();
               }else{  
               $('.hihi<?php echo e($key); ?>').addClass('background-blue'); 
               $('.pw').append(` 
               <div class="pt pt<?php echo e($key); ?>" id="pt<?php echo e($key); ?>">
                  <a href="javascript:;"><?php echo e($list->friends->user); ?> <span class="close<?php echo e($key); ?>">&times;</span></a> 
               </div> 
               `);
               }
            });  
            $('body').on('click','.close<?php echo e($key); ?>',function(){
            $('.pt<?php echo e($key); ?>').remove();
            $('.hihi<?php echo e($key); ?>').removeClass('background-blue'); 
            if($('.pu button').hasClass("background-blue")){
            $('.nexts').removeClass('disabled');
             }else{
            $('.nexts').addClass('disabled');
             }  
         })  
         </script> 

         
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>
  </div>
  </div>



<div class="messages  d-block">
<div class="left d-inline-block" style="height: 100%;width:35%; ">
   <div class="top-left  position-relative">
      <p><?php echo e(\Auth::user()->c_name); ?></p>
      <img src="<?php echo e(asset('img/direct-message.png')); ?>" class="openmodal cs">
   </div>
   <div class="bottom-left position-relative">
      <ul id="app">
    
         <?php $__currentLoopData = $chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php
            $userr =$list->friends;
            if( $list->friends->id == \Auth::id())
            $userr =$list->users;
         ?>
         <li class="clr" >
            <a href="<?php echo e(route('chat.show', $userr->id)); ?>">
               <img src="<?php echo e(pare_url_file($userr->avatar,'user')); ?>">
               <p><?php echo e($userr->c_name); ?></p>
               <br>
               <onlineuser v-bind:friend="<?php echo e($userr); ?>" v-bind:onlineusers="onlineUsers"></onlineuser>
            </a>
         </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
      </ul>
   </div>
</div>
<div class="rights d-inline-block" style="height: 100%;width:65%;background-color: white; ">
    <div class="d-flex we">
        <img src="<?php echo e(asset('img/direct-content.png')); ?>">
        <p><?php echo e(__('translate.Your Messages')); ?></p> 
        <p class="os"><?php echo e(__('translate.Send private photos and messages to a friend or group.')); ?></p>
        <button class="openmodal"><?php echo e(__('translate.Send Message')); ?></button>
    </div>
</div>
</section>

<script>
   $(function(){
      $('body').on('click','.pu button',function(){
      if($('.pu button').hasClass("background-blue")){
         $('.nexts').removeClass('disabled');
      }else{
         $('.nexts').addClass('disabled');
      }
      })
       $(".openmodal").on('click',function(){
         $('#id01').removeClass('d-none');
       })
       $(".closemodal").on('click',function(){
         $('#id01').addClass('d-none');
       })
      var modal= document.getElementById("id01");
       window.onclick=function(event){ 
          if(event.target==modal)
         $('#id01').addClass('d-none'); 
       } 

      $('#search').on('keyup',function(){
         var val =$(this).val();  
         var URL="<?php echo e(route('searchmess')); ?>";   
           $.get({
              url:URL,
              data:{value:val},
              success:function(data){ 
               $(".pu").empty(); 
              $(".pu").prepend(data);  
           }
           }) 
      })
   })
</script>
</body>  
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>  
</html><?php /**PATH D:\xampp\htdocs\instagram\resources\views/direct.blade.php ENDPATH**/ ?>