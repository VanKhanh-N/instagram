 
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
         <article class="border-gray position-relative">
            <div class="header ">
               <a class="text-black" href="<?php echo e($item->user->user); ?>"><img src="<?php echo e(pare_url_file($item->user->avatar,'user')); ?>" class="rounded-circle  d-inline-block img-user"><?php echo e($item->user->c_name); ?></a>
               <div class="float-right"><a><img src="<?php echo e(asset('img/edit.png')); ?>" class="img-edit"></a></div>
            </div>
            <img src="<?php echo e(pare_url_file($item->p_image,'profile')); ?>" class="article-img">
            
            <div class="attractive">
               <div class="d-block">
                  <div class="d-inline-block"><i class="fa fa-15x heart<?php echo e($item->id); ?> <?php echo e(\App\Models\Like::checkLove($item->id) ? 'fa-heart text-red' :'fa-heart-o'); ?>" onclick="likepost('<?php echo e($item->id); ?>')"></i> </div>
                  <div class="d-inline-block"><i class="fa fa-15x fa-comment-o"></i></div>
                  <div class="d-inline-block"><i class="fa fa-15x fa-share-alt"></i></div>
                  <div class="d-inline-block float-right"> <i class="fa fa-15x fa-bookmark-o float-right"></i></div>
                  <br>
                    <b class="zxm"> <b class="like<?php echo e($item->id); ?>"><?php echo e(\App\Models\Like::where('r_post',$item->id)->count()); ?></b> <?php echo e(__('translate.likes')); ?></b>
                   <div class="d-inline-block w-100">
                     <div class="status">
                        <a href="<?php echo e($item->user->user); ?>" class="text-black"><?php echo e($item->user->c_name); ?> </a><?php echo e($item->p_content); ?> <br>    
                        <br>
                     </div>
                      <div class="hdl<?php echo e($key); ?>">
                      <?php $__currentLoopData = \App\Models\Comment::where('c_post',$item->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=> $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                   
                     <div class="chat w-100 position-relative hjk<?php echo e($value); ?>" style="display:none">
                        <a href="<?php echo e($list->users->user); ?>" class="text-black"><?php echo e($list->users->c_name); ?></a> <?php echo e($list->c_comment); ?>

                        <i class="fa fa-heart-o float-right"></i> 
                     </div>  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                     </div>
                     <a href="javascript:;" class="text-gray button<?php echo e($key); ?>"><?php echo e(__('translate.View more comments')); ?></a> 
                  <br>
                     <a href="" class="text-gray" style="font-size:12px;line-height:30px"><?php echo e($item->created_at->diffForHumans($now)); ?> </a>
                     <hr>
                     <form class="position-relative form" action="<?php echo e(route('comment.post')); ?>">
                        <textarea rows="10"  autocomplete="off" class="textarea-<?php echo e($key); ?> textarea-comment<?php echo e($key); ?>" placeholder="<?php echo e(__('translate.Add a comment')); ?>..."></textarea>
                        <input type="hidden" value="<?php echo e($item->id); ?>" class="post-comment<?php echo e($key); ?>">
                        <input type="hidden" value="<?php echo e(\Auth::id()); ?>" class="user-comment<?php echo e($key); ?>">  
                        <input type="submit" class="os comment-submit submit-<?php echo e($key); ?> submit-comment<?php echo e($key); ?>" value="<?php echo e(__('translate.Post')); ?>">
                        <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 loading<?php echo e($key); ?>" style="display:none;position: absolute;right: 0;">
                     </form>
                  </div>
                  <div class="d-inline-block"></div>
               </div>
            </div>
         </article> 
         <script> 
         //load comment
           
         $('body').on('click','.button<?php echo e($key); ?>',function(){  
            
            loadmore(<?php echo e($key); ?>);
         }) 
         currentindex=0;
         maxindex ="<?php echo e(\App\Models\Comment::where('c_post',$item->id)->count()); ?>";
         function loadmore(id){  
            if(currentindex+3 >= maxindex){
               $('.button'+id).hide();
            }
            x=  window.scrollY;
            var maxresult = 3;

            for(var i = 0; i < maxresult; i++)
               {
                  $('.hjk'+(currentindex+i)).show();
               }
          
              window.scrollTo(0,x);
               currentindex += maxresult;
      }

           loadmore(<?php echo e($key); ?>);
         //yêu thích
         $(function(){ $('.heart<?php echo e($item->id); ?>').on('click',function(){
               $(this).toggleClass('text-red');
               $(this).toggleClass('fa-heart-o ');
               $(this).toggleClass('fa-heart');
         }); 
         //event comment
            $('.textarea-<?php echo e($key); ?>').on('keyup',function(){
               if(!$('.textarea-<?php echo e($key); ?>').val()){
               $('.submit-<?php echo e($key); ?>').addClass('disabled'); 
               $('.submit-<?php echo e($key); ?>').addClass('os'); 
               }
               else{ 
               $('.submit-<?php echo e($key); ?>').removeClass('disabled');
               $('.submit-<?php echo e($key); ?>').removeClass('os');
               }
            })
             
               //comment
      $(".submit-comment<?php echo e($key); ?>").on('click',function(e){
         e.preventDefault();
         var URL= $(this).parents('form').attr('action');
         var c_comment=$('.textarea-comment<?php echo e($key); ?>').val();
         var c_post=$('.post-comment<?php echo e($key); ?>').val();
         var c_user_id=$('.user-comment<?php echo e($key); ?>').val(); 
         
         $.get({ 
            url:URL,
            data:{c_comment:c_comment,c_post:c_post,c_user_id:c_user_id},
            beforeSend:function(){
               $('.loading<?php echo e($key); ?>').show();
               $('.submit-<?php echo e($key); ?>').addClass('os');
            },
            complete:function(){
               $('.loading<?php echo e($key); ?>').hide();
               $('.submit-<?php echo e($key); ?>').removeClass('os');
            }
         }).done(function(e){
            $(".hdl<?php echo e($key); ?>").append(`
            <div class="chat w-100 position-relative">
                        <a href="/${e.user.user}" class="text-black">${e.user.c_name}</a> ${c_comment}
                        <i class="fa fa-heart-o float-right"></i> 
                     </div>  
         `);
         $('.textarea-comment<?php echo e($key); ?>').val('');
         $('.submit-comment<?php echo e($key); ?>').addClass('disabled');
         });
      })
})
 
         </script>     
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\instagram\resources\views/layout/welcome.blade.php ENDPATH**/ ?>