<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>.user{margin-left:150px}</style>
<br> 
<br>
<br> 
<body>
   <section class="sd">
      
      <?php if(!$user->avatar): ?> 
      <label for="upload_user_avatar"> <img src="/img/no-user.png" class="rounded-circle user cs avatar_user_uploaded"></label>
     
      <?php elseif(substr($user->avatar,0,4)=='http'): ?>
      <img src="<?php echo e($user->avatar); ?>" class="rounded-circle user cs avatar_user_uploaded" id="myBtn-5">
      <?php else: ?>
      <img src="<?php echo e(pare_url_file($user->avatar,'user')); ?>" class="rounded-circle user cs avatar_user_uploaded" id="myBtn-5">
      <?php endif; ?>
      <img src="<?php echo e(asset('img/loading.gif')); ?>" class=" uploadavatar imguser" style="display:none;">
      
      </div>
      <form method="POST" enctype="multipart/form-data" id="form_upload_user_avatar">
         <?php echo csrf_field(); ?>
         <input type="file" onchange="uploadUserAvatar(this,'form_upload_user_avatar')" accept="image/*"  name="upload_user_avatar" class="d-none" id="upload_user_avatar">
      </form>
      <!-- modal user image -->
      <div id="myModal-5" class="modal">
         <div class="modal-content setting animate__animated animate__zoomIn" >
            <li class="hed"><a href="javascript:;" ><?php echo e(__('translate.Change Profile Photo')); ?></a></li>
            <li>
               <label for="change_user" class="text-blue change cs"><?php echo e(__('translate.Upload Photo')); ?></label>
               <form method="POST" enctype="multipart/form-data" id="form_change_user_avatar">
                  <?php echo csrf_field(); ?>
                  <input type="file" onchange="uploadUserAvatar(this,'form_change_user_avatar')" accept="image/*"  name="upload_user_avatar" class="d-none" id="change_user">
               </form>
            </li>
            <li><a href="javascript:;" class="text-red remove_current_photo"><?php echo e(__('translate.Remove Current Photo')); ?></a></li>
            <li class="cs" id="exit5"><a href=""><?php echo e(__('translate.Cancel')); ?></a></li>
         </div>
      </div>
      <div class="csa">
         <div class="clr csb">
            <span class="os" style="float:left"><?php echo e($user->user); ?></span>
            <?php if($user->user === \Auth::user()->user): ?>
            <a href=""><?php echo e(__('translate.Edit Profile')); ?></a>
            <i class="fa fa-2x fa-sun-o" id="myBtn-2"></i> 
            <span class="fa-stack fa-lg cs" id="myBtn"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-plus fa-stack-1x"></i></span> 
            <?php else: ?>  
            <div class="list-follow">
            <?php if(!$followed): ?>
            <button class="follow" onclick="follow('<?php echo e($user->id); ?>')">
                  <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 load<?php echo e($user->id); ?>" style="display:none">
                  <p class="text-follows<?php echo e($user->id); ?>"><?php echo e(__('translate.follow')); ?></p>
             </button>  
            <?php else: ?>
            <a href="<?php echo e(route('chat.show', $user->id)); ?>" class="message"><?php echo e(__('translate.Message')); ?></a>
            <a class="unfollow follows<?php echo e($user->id); ?>"href="javascript:;"  onclick="follow('<?php echo e($user->id); ?>')">
            <i class="fa  fa-user-times"></i>
            <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 load<?php echo e($user->id); ?>" style="display:none;margin-top: -11px;">
         </a>
            <?php endif; ?>
</div>
            <?php endif; ?>
         </div>
         <!-- modal setting -->
         <div id="myModal-2" class="modal ">
            <div class="modal-content setting animate__animated animate__zoomIn" >
               <li><a href=""><?php echo e(__('translate.Change Password')); ?></a></li>
               <li><a href=""><?php echo e(__('translate.Nametag')); ?></a></li>
               <li><a href=""><?php echo e(__('translate.Apps and Websites')); ?></a></li>
               <li><a href=""><?php echo e(__('translate.Notifications')); ?></a></li>
               <li><a href=""><?php echo e(__('translate.Privacy and Security')); ?></a></li>
               <li><a href=""><?php echo e(__('translate.Login Activity')); ?></a></li>
               <li><a href=""><?php echo e(__('translate.Emails from Instagram')); ?></a></li>
               <li><a href=""><?php echo e(__('translate.Report a Problem')); ?></a></li>
               <li><a href="<?php echo e(route('get.logout')); ?>"><?php echo e(__('translate.Log Out')); ?></a></li>
               <li><a href="#" id="exit"><?php echo e(__('translate.Cancel')); ?></a></li>
            </div>
         </div>
         <div class="clr csc">
            <p><b style="padding-right: 5px;"><?php echo e(count($post)); ?></b> <?php echo e(__('translate.posts')); ?></p>
            <p class="cs" id="myBtn-6"><b style="padding-right: 5px;" class="follower"><?php echo e(count($userFollow)); ?></b><?php echo e(__('translate.followers')); ?></p>
            <!-- modal setting -->
            <div id="myModal-6" class="modal">
               <div class="modal-content settings animate__animated animate__zoomIn" >
                  <li class="one"><?php echo e(ucwords(__('translate.followers'))); ?> <span class="float-right cs" id="exit6">&times;</span></li>
                 <div class="settingss">
                 <?php if(!count($userFollow)): ?> 
                  <li class="k-none"><i class="fa fa-lg fa-user-plus"></i></li>
                  <li class="k-none two"><?php echo e(ucwords(__('translate.followers'))); ?></li>
                  <li class="k-none three"><?php echo e(__("translate.You'll see all the people who follow you here.")); ?></li>
                  <?php else: ?>
                  <!-- số người theo dõi mình -->
                  <?php $__currentLoopData = $userFollow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                  <li class="clr user<?php echo e($list->user_id); ?>" style="height: 50px;">
                     <a href="<?php echo e($list->users->user); ?>" class="zx position-relative ">
                     <img src="<?php echo e(pare_url_file($list->users->avatar,'user')); ?>" class="w-35 rounded-circle"> 
                     <b class="zz"><?php echo e($list->users->user); ?></b><br>
                     <b class="os"><?php echo e($list->users->c_name); ?></b>
                     </a>
                     <?php if($list->user_id!=\Auth::id()): ?>
                     <?php if(\App\Models\Follow::checkFollow(\Auth::id(),$list->user_id)): ?>
                      <?php if($user->id != \Auth::id()): ?>
                     <button class="followss zc<?php echo e($list->user_id); ?>" onclick="follows('<?php echo e($list->user_id); ?>')" ><cen class="cen<?php echo e($list->user_id); ?>"><?php echo e(__('translate.folowing')); ?></cen>
                     <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 load<?php echo e($list->user_id); ?>" style="display:none;margin-top: -11px;">
                     <?php else: ?>
                     <button class="followss zc<?php echo e($list->user_id); ?>" onclick="followss('<?php echo e($list->user_id); ?>')" ><cen class="cen<?php echo e($list->user_id); ?>"><?php echo e(__('translate.folowing')); ?></cen>
                     <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 load<?php echo e($list->user_id); ?>" style="display:none;margin-top: -11px;">
                     <?php endif; ?>
                  </button>
                     <?php else: ?>  
                     <?php if($user->id != \Auth::id()): ?>
                     <button class="follows zc<?php echo e($list->user_id); ?>" onclick="follows('<?php echo e($list->user_id); ?>')" ><cen class="cen<?php echo e($list->user_id); ?>"><?php echo e(__('translate.follow')); ?></cen>
                      <img src="<?php echo e(asset('img/loading.gif')); ?>"  style="display:none;"class="w-30 load<?php echo e($list->user_id); ?>">
                  </button> 
                     <?php else: ?>
                     <button class="follows zc<?php echo e($list->user_id); ?>" onclick="followss('<?php echo e($list->user_id); ?>')" ><cen class="cen<?php echo e($list->user_id); ?>"><?php echo e(__('translate.follow')); ?></cen>
                      <img src="<?php echo e(asset('img/loading.gif')); ?>"  style="display:none;"class="w-30 load<?php echo e($list->user_id); ?>">
                     </button> 
                     <?php endif; ?>
                     <?php endif; ?>
                     <?php endif; ?>
                  </li> 
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  </div>
               </div>
            </div>
            <!--end modal-->
            <p class="cs" id="myBtn-7"><?php echo e(__('translate.folowing')); ?> <b class="count" style="float: none;"><?php echo e(count($areFollow)); ?></b><?php echo e(__('translate.following')); ?></p>
            <!-- modal setting -->
            <div id="myModal-7" class="modal">
               <div class="modal-content settings animate__animated animate__zoomIn" >
                  <li class="one"><?php echo e(ucwords(__('translate.followers'))); ?> <span class="float-right cs" id="exit7">&times;</span></li>
                 <div class="list">
                 <?php if(!count($areFollow)): ?>
                  <li><i class="fa fa-lg fa-user-plus"></i></li>
                  <li class="two"><?php echo e(ucwords(__('translate.folowing'))); ?></li>
                  <li class="three"><?php echo e(__("translate.You'll see all the people who follow you here.")); ?></li>
                  <?php else: ?>
                  <!-- đang theo dõi -->
                  <?php $__currentLoopData = $areFollow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                  <li class="clr users<?php echo e($list->friends->id); ?>" style="height: 50px;">
                     <a href="<?php echo e($list->friends->user); ?>" class="zx position-relative">
                     <img src="<?php echo e(pare_url_file($list->friends->avatar,'user')); ?>" class="w-35 rounded-circle"> 
                     <b class="zz"><?php echo e($list->friends->user); ?></b><br>
                     <b class="os"><?php echo e($list->friends->c_name); ?></b>
                     </a>
                     <?php if($list->friends->id!=\Auth::id()): ?> 
                     <?php if(\App\Models\Follow::checkFollow(\Auth::id(),$list->friends->id)): ?>
                     <?php if($user->id != \Auth::id()): ?>
                     <button class="followss zc<?php echo e($list->friends->id); ?>" onclick="follows('<?php echo e($list->friends->id); ?>')" ><cen class="cen<?php echo e($list->friends->id); ?>"><?php echo e(__('translate.folowing')); ?></cen>
                     <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 load<?php echo e($list->friends->id); ?>" style="display:none;margin-top: -11px;">
                     <?php else: ?>
                     <button class="followss zc<?php echo e($list->friends->id); ?>" onclick="followss('<?php echo e($list->friends->id); ?>')" ><cen class="cen<?php echo e($list->friends->id); ?>"><?php echo e(__('translate.folowing')); ?></cen>
                     <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 load<?php echo e($list->friends->id); ?>" style="display:none;margin-top: -11px;">
                     <?php endif; ?>
                  </button>
                     <?php else: ?> 
                     <?php if($user->id != \Auth::id()): ?> 
                     <button class="follows zc<?php echo e($list->friends->id); ?>" onclick="follows('<?php echo e($list->friends->id); ?>')" ><cen class="cen<?php echo e($list->friends->id); ?>"><?php echo e(__('translate.follow')); ?></cen>
                      <img src="<?php echo e(asset('img/loading.gif')); ?>"  style="display:none;"class="w-30 load<?php echo e($list->friends->id); ?>">
                  </button> 
                  <?php else: ?>
                  <button class="follows zc<?php echo e($list->friends->id); ?>" onclick="followss('<?php echo e($list->friends->id); ?>')" ><cen class="cen<?php echo e($list->friends->id); ?>"><?php echo e(__('translate.follow')); ?></cen>
                      <img src="<?php echo e(asset('img/loading.gif')); ?>"  style="display:none;"class="w-30 load<?php echo e($list->friends->id); ?>">
                  </button> 
                  <?php endif; ?>
                     <?php endif; ?>

                     <?php endif; ?>
                  </li> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                 </div>
               </div>
            </div>
            <!--end modal-->
         </div>
         <b class="hem"><?php echo e($user->c_name); ?></b>  
      </div>
   </section>
   <div class="image d-none">
      <div class="title first">
         <b><?php echo e(__('translate.Cancel')); ?></b>
         <p><?php echo e(__('translate.New Post')); ?></p>
         <a href="javascript:;" class="next"><?php echo e(__('translate.Next')); ?> <i class="fa fa-long-arrow-right"></i></a>
      </div>
      <div class="second d-none">
         <form action="<?php echo e(route('post.profile')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="title ">
               <a href="javascript:;" class="back"><i class="fa fa-long-arrow-left"></i> <?php echo e(__('translate.Back')); ?> </a>
               <p><?php echo e(__('translate.New Post')); ?></p>
               <button type="submit" class="submit"><?php echo e(__('translate.Share')); ?></button> 
               <img src="<?php echo e(asset('img/loading.gif')); ?>"  class="w-30 nos" style="display:none">
            </div>
            <textarea name="p_content" class="textarea" placeholder="Write a caption... (max 2000 charaters)"></textarea>
      </div>
      <img id="image-post" src="<?php echo e(asset('img/heart-outline.png')); ?>" >
   </div>
   
   <div class="posts">
   <div class="d-gri csd">
   <button id="first" class="bt" style="text-transform: uppercase;"><i class="fa fa-table"></i> <?php echo e(__('translate.posts')); ?></button>
   <button id="second"><i class="fa fa-television"></i> IGTV</button>
   <button id="third"  style="text-transform: uppercase;"><i class="fa  fa-arrows-alt"></i> <?php echo e(__('translate.saved')); ?></button>
   <button id="fourst"><i class="fa fa-user"></i> <?php echo e(__('translate.TAGGED')); ?></button> 
   </div> 
   <!-- modal upload profile and story -->
   <div id="myModal" class="modal"> 
   <div class="modal-content upload animate__animated animate__zoomIn ">
   <h4><?php echo e(__('translate.Upload photo')); ?></h4>
   <div class="button">
   <div class="label">
   <label for="profiles" class="cs"><?php echo e(__('translate.Add to Profile')); ?></label>  
   <!--file-->
   <input type="file" accept="image/*" name="profiles" accept="image/*" id="profiles" class='d-none'>
   <!--file-->
   <p><?php echo e(__('translate.or')); ?></p>
   </div>
   <div class="label label2">
   <label for="stories" class="cs"><?php echo e(__('translate.Add to Stories')); ?></label>
   <input type="file" accept="image/*" name="stories" id="stories"  accept="image/*" class="d-none"> 
   </div>
   </div>
   </div>
   </div> 
   </form>  
   <div class="post-image">
      <?php if(!count($post)): ?>
      <div class="clr">
         <br>
         <div class="hea">
            <b><?php echo e(__('translate.Start capturing and sharing your moments.')); ?></b>
            <p><?php echo e(__('translate.Get the app to share your first photo or video.')); ?></p>
            <br><br>
            <img src="<?php echo e(asset('img/appstore.png')); ?>" class="cs" style="height:40px;width:135px">
            <img src="<?php echo e(asset('img/chplay.png')); ?>" class="cs" style="height:40px;width:135px">
         </div>
      </div>
      <div><img src="<?php echo e(asset('img/everything.png')); ?>" class="float-left hed"></div>
      <br>
      <?php endif; ?>
      <div class="clr">
         <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
         <div class="cs cse"  id="myBtnn<?php echo e($val->id); ?>">
            <div class="clr csf">
               <i class="fa fa-heart"></i> <p class="likes<?php echo e($val->id); ?>"><?php echo e($val->p_favourite); ?></p>
               <i class="fa fa-comment"></i> <p class="comment<?php echo e($val->id); ?>"> <?php echo e($val->p_comment); ?></p>
            </div>
            <img data-img="<?php echo e(pare_url_file($val->p_image,'profile')); ?>" class="lazyload" id="image<?php echo e($key); ?>">  
         </div>
         <div id="myModall<?php echo e($val->id); ?>" class="modal hei">
            <div class="csg">
               <img src="<?php echo e(pare_url_file($val->p_image,'profile')); ?>" class="csq"> 
               <div class="cle">
                  <div class="heq">
                     <div class="hew"><a href="<?php echo e(route('get.home-page',$val->user->user)); ?>"><img src="<?php echo e(pare_url_file($val->user->avatar,'user')); ?>" class="avatar_user_uploaded"></a> </div>
                     <div class="hee">
                        <p><a href="<?php echo e(route('get.home-page',$val->user->user)); ?>"><b><?php echo e($val->user->c_name); ?> </a></b>
                           <?php if($val->user->id==$user->id): ?>
                           <?php else: ?>
                           &#8729; <b><?php echo e(__('translate.folowing')); ?></b>
                           <?php endif; ?>
                        </p>
                     </div>
                     <i class="fa fa-ellipsis-h"></i>
                  </div>
                  <div class="her hdl<?php echo e($val->id); ?>" id="hell">
                     <?php if($val->p_content!=''): ?>
                     <div class="clr het">
                        <div class="hew"><a href="<?php echo e(route('get.home-page',$val->user->user)); ?>"><img src="<?php echo e(pare_url_file($val->user->avatar,'user')); ?>" class="avatar_user_uploaded"></a> </div>
                        <div class="hep">
                           <p><a href="<?php echo e(route('get.home-page',$val->user->user)); ?>"><b><?php echo e($val->user->c_name); ?></a> </b> <?php echo e($val->p_content); ?></p>
                        </div>
                        <i class="fa fa-ellipsis-h"></i> 
                        <div class="os heo"><?php echo e($val->created_at->diffForHumans($now)); ?> 
                        </div>
                       
                     </div>  
                    
                     <?php endif; ?>   
                    <div class="list-comment<?php echo e($val->id); ?>">
                    <?php $__currentLoopData = \App\Models\Comment::where('c_post',$val->id)->orderBy('created_at','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                     <div class="clr het hjk<?php echo e($value); ?> "  style="display:none">
                      <div class="hew"><a href="<?php echo e(route('get.home-page',$cmt->users->user)); ?>"><img src="<?php echo e(pare_url_file($cmt->users->avatar,'user')); ?>" class="<?php echo e($cmt->c_user_id ==\Auth::id() ? 'avatar_user_uploaded' :''); ?>"></a> </div>
                        <div class="hep">
                           <p><b><a href="<?php echo e(route('get.home-page',$cmt->users->user)); ?>"><?php echo e($cmt->users->c_name); ?></a> </b> <?php echo e($cmt->c_comment); ?></p>
                        </div>
                        <i class="fa fa-ellipsis-h"></i>
                        <div class="os heo"><?php echo e($cmt->created_at->diffForHumans($now)); ?> </div>
                     </div> 
                     
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                     <div class="buttons"><button class="button<?php echo e($val->id); ?> ">+</button> </div>
                     <script>
                     
                     $('.button<?php echo e($val->id); ?>').on('click',function(){  
                           loadmore(); 
                     }) 
                     currentindex=0;
                     maxindex ="<?php echo e(\App\Models\Comment::where('c_post',$val->id)->count()); ?>";
                     function loadmore(){ 
                     x=  window.scrollY;
                     var maxresult = 5;

                     for(var i = 0; i < maxresult; i++)
                     {
                        $(".hjk"+(currentindex+i)).show();
                     }
                     if(currentindex+5>=maxindex){
                        $('.button<?php echo e($val->id); ?>').hide();
                     }
                     window.scrollTo(0,x);
                     currentindex += maxresult;

                  }

                  loadmore();
                     </script>
                  </div>
                  <?php
                  $class=" fa-heart-o ";
                  if(\App\Models\Like::checkLove($val->id))
                  $class="fa-heart text-red";
                  ?>
                  <div class="hey">
                     <i class="fa fa-15x heart<?php echo e($val->id); ?> <?php echo e($class); ?>" onclick="likepost('<?php echo e($val->id); ?>')"></i> 
                     <i class="fa fa-15x fa-comment-o"></i> 
                     <i class="fa fa-15x fa-share-alt"></i>
                     <i class="fa fa-15x fa-bookmark-o float-right"></i><br>
                     <p class="f-6 "><b class="view<?php echo e($val->id); ?>"><?php echo e($val->p_view); ?></b> <?php echo e(__('translate.views')); ?></p>
                     <p class="f-6 "><b class="like<?php echo e($val->id); ?>"><?php echo e($val->p_favourite); ?></b> <?php echo e(__('translate.likes')); ?></p> 
                     <p class="os">4 giờ trước</p>
                  </div>
                  <script> 
                     $('.heart<?php echo e($val->id); ?>').on('click',function(){
                        $(this).toggleClass('text-red');
                        $(this).toggleClass('fa-heart-o ');
                        $(this).toggleClass('fa-heart');
                     }) 
                  </script>
                  <div class="heu">
                     <form action="<?php echo e(route('comment.post')); ?>">
                        <?php echo csrf_field(); ?>
                        <textarea class="textarea-<?php echo e($val->id); ?> textarea-comment<?php echo e($val->id); ?>" placeholder="<?php echo e(__('translate.Add a comment')); ?>..."></textarea>
                        <input type="hidden" value="<?php echo e($val->id); ?>" class="post-comment<?php echo e($val->id); ?>">   
                        <button class="submit-<?php echo e($val->id); ?> submit-comment<?php echo e($val->id); ?> disabled"><?php echo e(__('translate.Post')); ?></button>
                        <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 load-comment" style="top: 10px;right: 15px;position: absolute;display:none;">
                     </form>
                  </div>
               </div>
            </div>
         </div>
         <script>   
         //click để scroll đến cuối trang
            // $('body').on('click','#myBtnn<?php echo e($val->id); ?>',function(){
            //    var $div = $("#hell"); 
            //    $div.scrollTop($div[0].scrollHeight);
            // })
            //không cho người dùng đăng khi chưa comment
            $('.textarea-<?php echo e($val->id); ?>').on('keyup',function(){
               if(!$('.textarea-<?php echo e($val->id); ?>').val())
               $('.submit-<?php echo e($val->id); ?>').addClass('disabled'); 
               else{ 
               $('.submit-<?php echo e($val->id); ?>').removeClass('disabled');
               }
            })
            //hiện modal bài viết 
          
            var thismodal<?php echo e($val->id); ?> = document.getElementById("myModall<?php echo e($val->id); ?>"); 
            var thisbtn<?php echo e($val->id); ?> = document.getElementById("myBtnn<?php echo e($val->id); ?>"); 
            var html=document.getElementsByTagName("html");
            thisbtn<?php echo e($val->id); ?>.onclick = function() {
            thismodal<?php echo e($val->id); ?>.style.display = "block";
            var post='<?php echo e($val->id); ?>';
            var URL ="<?php echo e(route('post.increview')); ?>";  
            $.get({
               url:URL,
               data:{post:post},
               success:function(e){  
                  $('.view<?php echo e($val->id); ?>').text(e.p_view);
               }
            })
            }   
            //ẩn modal bài viết
            thismodal<?php echo e($val->id); ?>.onclick = function(event) {   
               if (event.target == thismodal<?php echo e($val->id); ?>) {    
               thismodal<?php echo e($val->id); ?>.style.display = "none";
              
               }
            }
           
            //comment
            $(".submit-comment<?php echo e($val->id); ?>").on('click',function(e){
            e.preventDefault();
            var URL= $(this).parents('form').attr('action');
            var c_comment=$('.textarea-comment<?php echo e($val->id); ?>').val();
            var c_post=$('.post-comment<?php echo e($val->id); ?>').val();
            var c_user_id='<?php echo e(\Auth::id()); ?>'; 
            $.get({ 
            url:URL,
            data:{c_comment:c_comment,c_post:c_post,c_user_id:c_user_id},
            beforeSend:function(){
               $('.load-comment').show();
               $('.submit-<?php echo e($val->id); ?>').hide();
            },
            complete:function(){
               $('.load-comment').hide();
               $('.submit-<?php echo e($val->id); ?>').show();
            }
            }).done(function(e){
               if(e.user.avatar){
                  var img ="/uploads/user/"+e.user.avatar;
               }
               else{
                  img ='/img/no-user.png';
               }
            $('.comment<?php echo e($val->id); ?>').text(e.count.p_comment);
            $(".list-comment<?php echo e($val->id); ?>").prepend(`
            <div class="clr het">
            <div class="hew"><a href="/${e.user.user}"><img src="${img}" class="avatar_user_uploaded"></a> </div>
            <div class="hep"><p><b><a href="/${e.user.user}">${e.user.c_name}</a> </b>${c_comment}</p></div>
            <i class="fa fa-ellipsis-h"></i>
            <div class="os heo">1 giây trước </div>
            </div>
            `);
            $('.textarea-comment<?php echo e($val->id); ?>').val('');
            $('.submit-comment<?php echo e($val->id); ?>').addClass('disabled');

            // var $div = $("#hell"); 
            // $div.scrollBottom($div[0].scrollHeight); 
            });
            })
            
            
         </script>     
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </div>
   </div>
   <div class="d-none post-video">
      <?php if(!count($video)): ?>
      <div class="hef">
         <span class="fa-stack fa-2x fa-lg"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-video-camera fa-stack-1x"></i></span>
         <p><?php echo e(__('translate.Upload a Video')); ?></p>
         <p><?php echo e(__('translate.Videos must be between 1 and 60 minutes long.')); ?></p>
         <a href="<?php echo e(route('upload.video')); ?>"><?php echo e(__('translate.Upload')); ?></a>
      </div>
      <?php endif; ?>
   </div>
   <footer>
      <ul>
         <li class=" "><a href=""><?php echo e(__('translate.About')); ?></a></li>
         <li class=" "><a href="">Blog</a></li>
         <li class=" "><a href=""><?php echo e(__('translate.Jobs')); ?></a></li>
         <li class=" "><a href=""><?php echo e(__('translate.Help')); ?></a></li>
         <li class=" "><a href="">API</a></li>
         <li class=" "><a href=""><?php echo e(__('translate.Privacy')); ?></a></li>
         <li class=" "><a href=""><?php echo e(__('translate.Terms')); ?></a></li>
         <li class=" "><a href=""><?php echo e(__('translate.Top Accounts')); ?></a></li>
         <li class=" "><a href="">Hashtag</a></li>
         <li class=" "><a href=""><?php echo e(__('translate.Locations')); ?></a></li>
         <li class=" "><a href="<?php echo e(route('language',['vi'])); ?>">Tiếng Việt</a></li>
         <li class=" "><a href="<?php echo e(route('language',['en'])); ?>">English</a></li>
      </ul>
      <br> 
   </footer>
</body>
<p class="os" style="text-align:center">&copy; 2020 INSTAGRAM FROM FACEBOOK</p>
<br>
<script src="<?php echo e(asset('js/post.js')); ?>"></script> 
<script src="<?php echo e(asset('js/avatar.js')); ?>"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>  
<script>
//lazy load img
let id="<?php echo e(count($post)); ?>";
let options={
   root:null,
   rootMargin:'0px',
   threshold:0.25
};
let callback =(entries,observer)=>{
   entries.forEach(entry=>{
      if(entry.isIntersecting && entry.target.className === 'lazyload'){
         let imageUrl = entry.target.getAttribute('data-img');
         if(imageUrl){
            entry.target.src =imageUrl;
            observer.unobserve(entry.target);
         }
      }
   })
} 
let observer =new IntersectionObserver(callback,options);
for( var i=0;i<id;i++) { 
observer.observe(document.querySelector('#image'+i)); 
} 
</script>
<script type="text/javascript"> 
   //add to profile
      $('#profiles').on('change',function(ev){ 
        var reader=new FileReader(); 
        reader.onload=function(ev){
          $('#image-post').attr('src',ev.target.result).css('width','350px').css('height','350px').css('margin-bottom','50px'); 
        }
        reader.readAsDataURL(this.files[0]);   
            $('#myModal').hide();   
            $('.image').removeClass('d-none');
         
      });
   //add to stories
      $('#stories').on('change',function(ev){ 
        var reader=new FileReader(); 
        reader.onload=function(ev){
          $('#image-post').attr('src',ev.target.result).css('width','350px').css('height','350px').css('margin-bottom','50px'); 
        }
        reader.readAsDataURL(this.files[0]);   
            $('#myModal').hide();   
            $('.image').removeClass('d-none');
         
      });
   
   
</script>
<script>
   $('#first').on('click',function(e){
      e.preventDefault();
      $('.post-image').removeClass('d-none');
      $('.post-video').addClass('d-none');
   
      
      $(this).addClass('bt');
      $('#second').removeClass('bt');
   })
   $('#second').on('click',function(e){
      e.preventDefault();
      $('.post-image').addClass('d-none');
      $('.post-video').removeClass('d-none');
      
      $(this).addClass('bt');
      $('#first').removeClass('bt');
   })
</script>  
<script>
   $(function(){  
      $('.next').on('click',function(){
            $('.first').addClass('d-none');
            $('.second').removeClass('d-none');
       })
       $('.back').on('click',function(){
            $('.first').removeClass('d-none');
            $('.second').addClass('d-none');
       })
      $('.image b').css("cursor","pointer");
            $('.image b').on('click',function(){
            $('.image').addClass('d-none');
       })
       $('.submit').on('click',function(){
         $(this).hide();
         $('.nos').show();
      })
   })
   
   var modal6 = document.getElementById("myModal-6");
   var btn6 = document.getElementById("myBtn-6");
   var exit6 = document.getElementById("exit6");
   
   btn6.onclick = function() {
      modal6.style.display = "block";
   } 
   exit6.onclick = function() {
      modal6.style.display = "none";
   } 
   
   var modal7 = document.getElementById("myModal-7");
   var btn7 = document.getElementById("myBtn-7");
   var exit7 = document.getElementById("exit7");
   
   btn7.onclick = function() {
      modal7.style.display = "block";
   } 
   exit7.onclick = function() {
      modal7.style.display = "none";
   } 

  
   window.onclick = function(event) { 
      if (event.target == modal) {    
      modal.style.display = "none";
      }
   
      if (event.target == modal2) {    
      modal2.style.display = "none";
      }
    
      if (event.target == modal5) {    
      modal5.style.display = "none";
      }
      if (event.target == modal6) {    
      modal6.style.display = "none";
      }
      if (event.target == modal7) {    
      modal7.style.display = "none";
      }
      }
   var modal = document.getElementById("myModal"); 
   var btn = document.getElementById("myBtn"); 
   btn.onclick = function() {
   modal.style.display = "block";
   }  
   
   
   var modal2 = document.getElementById("myModal-2");
   var btn2 = document.getElementById("myBtn-2");
   var exit = document.getElementById("exit");
   
   btn2.onclick = function() {
      modal2.style.display = "block";
   } 
   exit.onclick = function(event) {
      event.preventDefault();    
      modal2.style.display = "none";
   }
   var modal5 = document.getElementById("myModal-5");
   
   
   
   
</script>
<script>
   $('body').on('click','#myBtn-5',function(){
      $('#myModal-5').show();
   })
   $('body').on('click','#exit5',function(){
      $('#myModal-5').hide();
   })
</script>
</body>
</html><?php /**PATH D:\xampp\htdocs\instagram\resources\views/home-page.blade.php ENDPATH**/ ?>