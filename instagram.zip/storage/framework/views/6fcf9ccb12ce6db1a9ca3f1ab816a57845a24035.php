<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video call</title>
</head>
<body>  
<script>
function onVidyoClientLoaded(status){
    console.log("VidyoClient load state -"+status.state);
    if(status.state =="READY"){
        VC.CreateVidyoConnector({
  viewId: "renderer",                            // Div ID where the composited video will be rendered, see VidyoConnector.html
  viewStyle: "VIDYO_CONNECTORVIEWSTYLE_Default", // Visual style of the composited renderer
  remoteParticipants: 15,                        // Maximum number of participants
  logFileFilter: "warning all@VidyoConnector info@VidyoClient",
  logFileName:"",
  userData:""
}).then(function(vidyoConnector) {
   vidyoConnector.Connect({
     host: "prod.vidyo.io",
     token: generatedToken,
     displayName: "John Smith",
     resourceId: "JohnSmithRoom",
     // Define handlers for connection events.
     onSuccess: function()            {/* Connected */},
     onFailure: function(reason)      {/* Failed */},
     onDisconnected: function(reason) {/* Disconnected */}
    }).then(function(status) {
        if (status) {
            console.log("ConnectCall Success");
        } else {
            console.error("ConnectCall Failed");
        }
    }).catch(function() {
        console.error("ConnectCall Failed");
    });
}).catch(function() {
  console.error("CreateVidyoConnector Failed");
});
    }
}
function joinCall(){
    vidyoConnector.Connect({
        host:"prod.vidyo.io",
        token:"",
        displayName:"John Smith",
        resourceId:"JohnSmithRoom",
        onSuccess:function(){
            console.log("Connect success");
        },
        onFailure: function(reason) {
            console.log("Connect fail");
        },
        onDisconnected: function(reason){
            console.log("disconnect -"+reason);
        }
    })
}
</script>
<script src="https://static.vidyo.io/latest/javascript/VidyoClient/VidyoClient.js?onload=onVidyoClientLoaded"></script>
    <h3>Hi <?php echo e(\Auth::user()->c_name); ?></h3>
    <button onclick="joinCall()"></button>
    <div id="renderer">Join</div>
</body> 
</html><?php /**PATH D:\xampp\htdocs\instagram\resources\views/direct/videocall.blade.php ENDPATH**/ ?>