<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<body>
   <br>
   <br>
   <br>
   <div class="container">
   <div class="d-block">
      <div class="d-inline-block left border-gray">
         <section>
            <ul class="d-flex story position-relative mySlides">
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
               <li>
                  <a>
                     <img src="<?php echo e(asset('img/be-giang.png')); ?>" class="img-story rounded-circle d-inline-block">
                     <div>26.imei     </div>
                  </a>
               </li>
            </ul>
         </section>
     <div class="postss conntent" data-next-page="<?php echo e($posts->nextPageUrl()); ?>">
     <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
         <article class="border-gray position-relative">
            <div class="header ">
               <a class="text-black" href="<?php echo e($item->user->user); ?>"><img src="<?php echo e(pare_url_file($item->user->avatar,'user')); ?>" class="rounded-circle  d-inline-block img-user"><?php echo e($item->user->c_name); ?></a>
               <div class="float-right"><a><img src="<?php echo e(asset('img/edit.png')); ?>" class="img-edit"></a></div>
            </div>
            <img src="<?php echo e(pare_url_file($item->p_image,'profile')); ?>" class="article-img">
            
            <div class="attractive">
               <div class="d-block">
                  <div class="d-inline-block"><i class="fa fa-15x heart<?php echo e($item->id); ?> <?php echo e(\App\Models\Like::checkLove($item->id) ? 'fa-heart text-red' :'fa-heart-o'); ?>" onclick="likepost('<?php echo e($item->id); ?>')"></i> </div>
                  <div class="d-inline-block"><i class="fa fa-15x fa-comment-o"></i></div>
                  <div class="d-inline-block"><i class="fa fa-15x fa-share-alt"></i></div>
                  <div class="d-inline-block float-right"> <i class="fa fa-15x fa-bookmark-o float-right"></i></div>
                  <br>
                    <b class="zxm"> <b class="like<?php echo e($item->id); ?>"><?php echo e(\App\Models\Like::where('r_post',$item->id)->count()); ?></b> <?php echo e(__('translate.likes')); ?></b>
                   <div class="d-inline-block w-100">
                     <div class="status">
                        <a href="<?php echo e($item->user->user); ?>" class="text-black"><?php echo e($item->user->c_name); ?> </a><?php echo e($item->p_content); ?> <br>    
                        <br>
                     </div>
                      <div class="hdl<?php echo e($key); ?>">
                      <?php $__currentLoopData = \App\Models\Comment::where('c_post',$item->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=> $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                   
                     <div class="chat w-100 position-relative hjk<?php echo e($value); ?>" style="display:none">
                        <a href="<?php echo e($list->users->user); ?>" class="text-black"><?php echo e($list->users->c_name); ?></a> <?php echo e($list->c_comment); ?>

                        <i class="fa fa-heart-o float-right"></i> 
                     </div>  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                     </div>
                     <a href="javascript:;" class="text-gray button<?php echo e($key); ?>"><?php echo e(__('translate.View more comments')); ?></a> 
                  <br>
                     <a href="" class="text-gray" style="font-size:12px;line-height:30px"><?php echo e($item->created_at->diffForHumans($now)); ?> </a>
                     <hr>
                     <form class="position-relative form" action="<?php echo e(route('comment.post')); ?>">
                        <textarea rows="10"  autocomplete="off" class="textarea-<?php echo e($key); ?> textarea-comment<?php echo e($key); ?>" placeholder="<?php echo e(__('translate.Add a comment')); ?>..."></textarea>
                        <input type="hidden" value="<?php echo e($item->id); ?>" class="post-comment<?php echo e($key); ?>">
                        <input type="hidden" value="<?php echo e(\Auth::id()); ?>" class="user-comment<?php echo e($key); ?>">  
                        <input type="submit" class="os comment-submit submit-<?php echo e($key); ?> submit-comment<?php echo e($key); ?>" value="<?php echo e(__('translate.Post')); ?>">
                        <img src="<?php echo e(asset('img/loading.gif')); ?>" class="w-30 loading<?php echo e($key); ?>" style="display:none;position: absolute;right: 0;">
                     </form>
                  </div>
                  <div class="d-inline-block"></div>
               </div>
            </div>
         </article> 
         <script> 
         //load comment
           
         $('body').on('click','.button<?php echo e($key); ?>',function(){  
            
            loadmore(<?php echo e($key); ?>);
         }) 
         currentindex=0;
         maxindex ="<?php echo e(\App\Models\Comment::where('c_post',$item->id)->count()); ?>";
         function loadmore(id){  
            if(currentindex+3 >= maxindex){
               $('.button'+id).hide();
            }
            x=  window.scrollY;
            var maxresult = 3;

            for(var i = 0; i < maxresult; i++)
               {
                  $('.hjk'+(currentindex+i)).show();
               }
          
              window.scrollTo(0,x);
               currentindex += maxresult;
      }

           loadmore(<?php echo e($key); ?>);
         //yêu thích
         $(function(){ $('.heart<?php echo e($item->id); ?>').on('click',function(){
               $(this).toggleClass('text-red');
               $(this).toggleClass('fa-heart-o ');
               $(this).toggleClass('fa-heart');
         }); 
         //event comment
            $('.textarea-<?php echo e($key); ?>').on('keyup',function(){
               if(!$('.textarea-<?php echo e($key); ?>').val()){
               $('.submit-<?php echo e($key); ?>').addClass('disabled'); 
               $('.submit-<?php echo e($key); ?>').addClass('os'); 
               }
               else{ 
               $('.submit-<?php echo e($key); ?>').removeClass('disabled');
               $('.submit-<?php echo e($key); ?>').removeClass('os');
               }
            })
             
               //comment
      $(".submit-comment<?php echo e($key); ?>").on('click',function(e){
         e.preventDefault();
         var URL= $(this).parents('form').attr('action');
         var c_comment=$('.textarea-comment<?php echo e($key); ?>').val();
         var c_post=$('.post-comment<?php echo e($key); ?>').val();
         var c_user_id=$('.user-comment<?php echo e($key); ?>').val(); 
         
         $.get({ 
            url:URL,
            data:{c_comment:c_comment,c_post:c_post,c_user_id:c_user_id},
            beforeSend:function(){
               $('.loading<?php echo e($key); ?>').show();
               $('.submit-<?php echo e($key); ?>').addClass('os');
            },
            complete:function(){
               $('.loading<?php echo e($key); ?>').hide();
               $('.submit-<?php echo e($key); ?>').removeClass('os');
            }
         }).done(function(e){
            $(".hdl<?php echo e($key); ?>").append(`
            <div class="chat w-100 position-relative">
                        <a href="/${e.user.user}" class="text-black">${e.user.c_name}</a> ${c_comment}
                        <i class="fa fa-heart-o float-right"></i> 
                     </div>  
         `);
         $('.textarea-comment<?php echo e($key); ?>').val('');
         $('.submit-comment<?php echo e($key); ?>').addClass('disabled');
         });
      })
})
 
         </script>     
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
         </div>
         <div class="loading" style="text-align:center">
         <img src="<?php echo e(asset('img/loadingg.gif')); ?>"style="width:250px;height:250px">
         </div>
      </div>
      <div class="d-inline-block right" >
         <div class="d-block">
            <div class="d-inline-block"><a href="<?php echo e(\Auth::user()->user); ?>"><img src="<?php echo e(pare_url_file(\Auth::user()->avatar,'user')); ?>" class="rounded-circle w-50"></a></div>
            <div class="d-inline-block">
               <div class="user-link"><a href="<?php echo e(\Auth::user()->user); ?>" class="text-black"><?php echo e(\Auth::user()->user); ?></a></div>
               <div class="user-name" >
                  <p class="os"><a href="<?php echo e(\Auth::user()->user); ?>"><?php echo e(\Auth::user()->c_name); ?></a></p>
               </div>
            </div>
            <br><br>  
            <div class="d-flex w-100">
               <p class="text-gray w-100"><?php echo e(__('translate.Suggestions For You')); ?></p>
               <a href="" class="text-black float-right w-100" style="font-size:12px"><?php echo e(__('translate.See All')); ?></a>
            </div>

            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!\App\Models\Follow::where(['user_id'=>\Auth::id(),'followed'=>$list->id])->count()): ?>
            <div class="d-inline-block position-relative suggest">
               <div class="d-inline-block">
               <?php if(substr($list->avatar,0,4)=='http'): ?>
                <a href="<?php echo e(route('get.home-page',$list->user)); ?>"><img src="<?php echo e($list->avatar); ?>" class="rounded-circle"></a>
                <?php else: ?>
               <a href="<?php echo e(route('get.home-page',$list->user)); ?>"><img src="<?php echo e(pare_url_file($list->avatar,'user')); ?>" class="rounded-circle"></a>
                <?php endif; ?>  
               </div>   
               <div class="d-inline-block ">
                  <div class="w-100 user-link"><a href="<?php echo e(route('get.home-page',$list->user)); ?>" class="text-black"><?php echo e($list->user); ?></a></div>
                  <br>
                  <?php if(\App\Models\Follow::where(['user_id'=>$list->id,'followed'=>\Auth::id()])->count()): ?>
                  <div class="w-100 user-name">
                     <p class="text-gray">Theo dõi bạn</p>
                  </div>
                  <?php endif; ?>
               </div>
               <div class="d-inline-block" style="position: absolute; top: 0;right: 0;margin-top: 10px;">
                  <p class="cs follow<?php echo e($list->id); ?>  text-blue" onclick="follow('<?php echo e($list->id); ?>')"><?php echo e(__('translate.follow')); ?></p>
                  <div class="load<?php echo e($list->id); ?>" style="margin-top:-10px;display:none">
                  <img src="<?php echo e(asset('img/loading.gif')); ?>">
                  </div>
               </div>
            </div>
            <script>
            $(".follow<?php echo e($list->id); ?>").on("click",function(){ 
               $(this).toggleClass("text-blue");
            })
            </script>
            <?php endif; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="about-us">
               <ul style="width: 80%;line-height:20px;margin-top: 30px;font-size:12px;opacity: 0.5;">
                  <li class="d-inline-block "><a href=""><?php echo e(__('translate.About')); ?></a>	&#8226;</li>
                  <li class="d-inline-block "><a href=""><?php echo e(__('translate.Help')); ?></a>	&#8226;</li>
                  <li class="d-inline-block "><a href=""><?php echo e(__('translate.Press')); ?></a>	&#8226;</li>
                  <li class="d-inline-block "><a href="">API</a>	&#8226;</li>
                  <li class="d-inline-block "><a href=""><?php echo e(__('translate.Jobs')); ?></a>	&#8226;</li>
                  <li class="d-inline-block "><a href=""><?php echo e(__('translate.Privacy')); ?></a>	&#8226;</li>
                  <li class="d-inline-block "><a href=""><?php echo e(__('translate.Terms')); ?></a>	&#8226;</li>
                  <li class="d-inline-block "><a href=""><?php echo e(__('translate.Locations')); ?></a>	&#8226;</li>
                  <li class="d-inline-block "><a href=""><?php echo e(__('translate.Top Accounts')); ?></a>	&#8226;</li>
                  <li class="d-inline-block "><a href="">Hashtag</a>	&#8226;</li>
                  <li class="d-inline-block "><a href="<?php echo e(route('language',['vi'])); ?>">English</a>	&#8226;</li>
                  <li class="d-inline-block "><a href="<?php echo e(route('language',['en'])); ?>">Tiếng Việt</a></li>
               </ul>
               <br>
            </div>
            <p class="text-gray" style="font-size:12px">&copy; 2020 INSTAGRAM FROM FACEBOOK</p>
         </div>
      </div>
   </div>
   <script type="text/javascript" src="<?php echo e(asset('slick/slick/slick.js')); ?>"></script>
   <script src="<?php echo e(asset('js/style.js')); ?>"></script>
   <script src="<?php echo e(asset('js/post.js')); ?>"></script>
   <script src="https://use.fontawesome.com/452826394c.js"></script>
    <script>
    $(document).ready(function(){
       $('.loading').hide();
       $(window).scroll(fetchPost);
       function fetchPost(){
          var page=$('.conntent').data('next-page');
          if(page !== null){
             $('.loading').show()   
             clearTimeout($.data(this),"scrollCheck");
             $.data(this,"scrollCheck",setTimeout(function(){
                var scroll_position =$(window).height()+$(window).scrollTop()+100;
                if(scroll_position>=$(document).height()){
                   $.get(page,function(data){
                     $('.postss').append(data.posts);
                     $('.conntent').data('next-page',data.next_page);
                   })
                   $('.loading').hide()
                }
             },2000))
          }else{
            $('.loading').hide()
          }
       }
    })
    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\instagram\resources\views/welcome.blade.php ENDPATH**/ ?>