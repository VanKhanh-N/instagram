
<meta name="friendId" content="<?php echo e($friend->id); ?>">
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<div id="app">
      <div class="messages  d-block">
        <div class="left d-inline-block" style="height: 100%;width:35%; ">
            <div class="top-left  position-relative">
                <p><?php echo e(\Auth::user()->c_name); ?></p>
                <img src="<?php echo e(asset('img/direct-message.png')); ?>">
            </div>
            <div class="bottom-left">
                <ul>   
                <?php if(!count(\App\Models\Chat::where(['user_id'=>\Auth::id(),'friend_id'=>$friend->id])->get())
                &&
                !count(\App\Models\Chat::where(['friend_id'=>\Auth::id(),'user_id'=>$friend->id])->get())
                ): ?>
                <a href="<?php echo e(route('chat.show', $friend->id)); ?>">
                    <li class="clr">
                            <img src="<?php echo e(pare_url_file($friend->avatar,'user')); ?>">
                            <p><?php echo e($friend->c_name); ?></p><br>
                            <onlineuser v-bind:friend="<?php echo e($friend); ?>" v-bind:onlineusers="onlineUsers"></onlineuser>
                    </li> 
                </a> 
                <?php endif; ?> 
                
                <?php $__currentLoopData = $chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $userr =$list->friends;
                    if( $list->friends->id == \Auth::id())
                    $userr =$list->users;
                ?>
                <a href="<?php echo e(route('chat.show', $userr->id)); ?>">
                    <li class="clr" >
                        <img src="<?php echo e(pare_url_file($userr->avatar,'user')); ?>">
                        <p><?php echo e($userr->c_name); ?></p>
                        <br>
                        <onlineuser v-bind:friend="<?php echo e($userr); ?>" v-bind:onlineusers="onlineUsers"></onlineuser>  
                    </li>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </ul>
            </div>
        </div>
        
        <div class="rights d-inline-block" style="height: 100%;width:65%;background-color: white; ">
            
            <div class="top-right position-relative ">
               <div class="user">
                    <a href="<?php echo e(route('get.home-page',$friend->user)); ?>">
                        <img src="<?php echo e(pare_url_file($friend->avatar,'user')); ?>"   class="rounded-circle ">
                    <p><?php echo e($friend->c_name); ?></p>
                      <onlineuser v-bind:friend="<?php echo e($friend); ?>" v-bind:onlineusers="onlineUsers"></onlineuser> 
                    </a>
               </div>
               <a href="" class="info"><i class="fa fa-lg fa-info"></i></a>
               <a href="" style="float:right;padding:25px"><i class="fa fa-lg fa-video-camera"></i></a>
            </div> 
           
            <chat v-bind:chats="chats" v-bind:userid="<?php echo e(Auth::user()->id); ?>" v-bind:friendid="<?php echo e($friend->id); ?>"></chat>
           
        </div>
      </div>
      </div> 
    </section>
      
</body>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>  
</html> 
<?php /**PATH D:\xampp\htdocs\instagram\resources\views/direct/chat.blade.php ENDPATH**/ ?>